(function($) {
    $(window).load(function() {
        $('.flexslider').flexslider({
	            animation: 'fade',
				rtl: true
	    });
	});
})(jQuery)